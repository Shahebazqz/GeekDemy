﻿using System.Collections.Generic;
namespace GeekTrust
{
    public enum Coupon
    {
        B4G1,
        DEAL_G20,
        DEAL_G5,
        NONE
    }
    interface ICoupon
    {
        Coupon CouponName { get; set; }
        CouponDetails ApplyCoupon(List<PurchasedProgramme> programmes);
    }
}
