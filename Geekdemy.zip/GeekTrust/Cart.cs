﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace GeekTrust
{
    public class Cart
    {
        private List<PurchasedProgramme> purchasedProgrammes;
        private bool isProMembershipPurchased;
        private double proMembershipDiscount;
        private double proMembershipFees = 200;
        private double totalAmount;
        private double subTotal = 0;
        private readonly string addProgrammeCommand = "ADD_PROGRAMME";
        private readonly string addProMembershipCommand = "ADD_PRO_MEMBERSHIP";
        private readonly string applyCouponCommand = "APPLY_COUPON";
        private readonly string printBillCommand = "PRINT_BILL";
        public List<PurchasedProgramme> PurchasedProgrammes
        {
            get { return purchasedProgrammes; }
            set { purchasedProgrammes = value; }
        }
        public bool IsProMembershipPurchased
        {
            get { return isProMembershipPurchased; }
            set { isProMembershipPurchased = value; }
        }
        public double ProMembershipDiscount
        {
            get { return proMembershipDiscount; }
            set { proMembershipDiscount = value; }
        }
        public double ProMembershipFees
        {
            get { return proMembershipFees; }
            set { proMembershipFees = value; }
        }
        public double TotalAmount
        {
            get { return totalAmount; }
            set { totalAmount = value; }
        }
        public double SubTotal
        {
            get { return subTotal; }
            set { subTotal = value; }
        }

        public Cart()
        {
            Program.AllProgrammes = new List<ProgrammeDetails>() {
                new ProgrammeDetails{ ProgrammeName="CERTIFICATION",ProgrammeFees=3000},
                new ProgrammeDetails{ ProgrammeName="DEGREE",ProgrammeFees=5000},
                new ProgrammeDetails{ ProgrammeName="DIPLOMA",ProgrammeFees=2500}
            };
        }
        public Cart InitializeValues(string[] commands)
        {
            Program.AddedCoupons = new List<Coupon>();

            this.purchasedProgrammes = new List<PurchasedProgramme>();

            for (int i = 0; i < commands.Count(); i++)
                CheckCommand(commands[i]);

            CalculateSubTotal();

            return this;
        }
        private void CheckCommand(string command)
        {
            if (command.Contains(addProgrammeCommand))
                AddProgramme(command);

            else if (command.Contains(addProMembershipCommand))
                this.isProMembershipPurchased = true;

            else if (command.Contains(applyCouponCommand))
                AddCoupon(command);
            else if (command.Contains(printBillCommand))
                return;
            else
                throw new NullReferenceException("Invalid Input Command");
        }
        private void AddCoupon(string command)
        {
            string[] input = command.Split(' ');

            Coupon coupon;

            if (Enum.TryParse<Coupon>(input[1], out coupon))
                Program.AddedCoupons.Add(coupon);

            else
                throw new NullReferenceException("Invalid Coupon Name");
        }
        private void AddProgramme(string command)
        {
            string[] programme = command.Split(' ');

            if (programme[0] != addProgrammeCommand)
                throw new NullReferenceException("Invalid Input Command");

            try
            {
                this.purchasedProgrammes.Add(new PurchasedProgramme
                {
                    Name = programme[1],
                    Quantity = Convert.ToInt32(programme[2]),
                    Fees = Program.AllProgrammes.Find(e => e.ProgrammeName == programme[1]).ProgrammeFees
                });
            }
            catch (System.NullReferenceException) { throw new NullReferenceException("Invalid Programme Name"); }

            catch (System.FormatException) { throw new NullReferenceException("Invalid Quantity"); }
        }
        private void CalculateSubTotal()
        {
            this.totalAmount = this.purchasedProgrammes.Sum(e => e.Fees * e.Quantity);

            this.subTotal = this.totalAmount;
        }

    }
}
