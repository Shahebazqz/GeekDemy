﻿using System.Collections.Generic;

namespace GeekTrust
{
    public static class ProMembership
    {
        private const double discountForDiploma = 0.01;
        private const double discountForCertification = 0.02;
        private const double discountForDegree = 0.03;
        private const string diploma = "DIPLOMA";
        private const string certification = "CERTIFICATION";
        private const string degree = "DEGREE";
        private static double getMembershipDiscount(string programmeName, double fees)
        {
            switch (programmeName)
            {
                case diploma:
                    fees = fees * discountForDiploma;
                    break;
                case certification:
                    fees = fees * discountForCertification;
                    break;
                case degree:
                    fees = fees * discountForDegree;
                    break;
            }
            return fees;
        }
        public static void CheckAndCalculateMembershipDiscount(ref Cart cart)
        {
            cart.ProMembershipDiscount = Program.zero;
            if (!cart.IsProMembershipPurchased)
            {
                cart.ProMembershipFees = Program.zero;
                return;
            }
            cart = UpdateMemebershipDiscountInCart(cart);
            cart.TotalAmount += cart.ProMembershipFees;
            cart.TotalAmount -= cart.ProMembershipDiscount;
            cart.SubTotal = cart.TotalAmount;
        }
        private static Cart UpdateMemebershipDiscountInCart(Cart cart)
        {
            for (int i = 0; i < cart.PurchasedProgrammes.Count; i++)
            {
                var discount = getMembershipDiscount(cart.PurchasedProgrammes[i].Name, cart.PurchasedProgrammes[i].Fees);
                cart.PurchasedProgrammes[i].Fees = cart.PurchasedProgrammes[i].Fees - discount;
                cart.ProMembershipDiscount += discount * cart.PurchasedProgrammes[i].Quantity;
            }
            return cart;
        }
    }
}
