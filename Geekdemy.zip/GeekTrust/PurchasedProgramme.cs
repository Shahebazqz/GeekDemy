﻿namespace GeekTrust
{
    public class PurchasedProgramme : ProgrammeDetails
    {
        private int programmeQuantity;
        private double programmeFees;
        private string programmeName;
        public int Quantity
        {
            get { return programmeQuantity; }   
            set { programmeQuantity = value; }
        }
        public double Fees
        {
            get { return programmeFees; }
            set { programmeFees = value; }
        }
        public string Name
        {
            get { return programmeName; }
            set { programmeName = value; }
        }

    }
}
