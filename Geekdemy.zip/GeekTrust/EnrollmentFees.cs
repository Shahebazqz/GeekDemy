﻿namespace GeekTrust
{
    public class EnrollmentFees
    {
        private bool isApplicable;
        private double fees = 500;
        private const double MinimumTotalAmountForFreeEnrollment = 6666;
        public double Fees
        {
            get { return fees; }
            set { fees = value; }
        }
        public EnrollmentFees CheckEnrollmentFeesApplicableOrNot(double totalAmount)
        {
            this.isApplicable = totalAmount < MinimumTotalAmountForFreeEnrollment ? true : false;
            if (!this.isApplicable) this.fees = Program.zero;
            return this;
        }
    }
}
