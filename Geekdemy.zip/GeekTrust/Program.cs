﻿using System;
using System.Collections.Generic;
using System.IO;

namespace GeekTrust
{
    class Program
    {
        private static List<ProgrammeDetails> allProgrammes;
        private static List<Coupon> addedCoupons;
        private static readonly double zero_ = 0;

        public static List<ProgrammeDetails> AllProgrammes
        {
            get { return allProgrammes; }
            set { allProgrammes = value; }
        }
        public static List<Coupon> AddedCoupons
        {
            get { return addedCoupons; }
            set { addedCoupons = value; }
        }
        public static double zero
        {
            get { return zero_; }
        }
        static void Main(string[] args)
        {
            try
            {
                string[] inputData = File.ReadAllLines(args[0]);

                CourseSelection courseSelection = new CourseSelection(inputData);

                courseSelection.CheckAndApplyCoupon();

                courseSelection.CheckAndApplyEnrollment();

                courseSelection.PrintOutput();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
        }
    }
}
