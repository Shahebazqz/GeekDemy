﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GeekTrust
{
    public class CourseSelection
    {
        private Cart cart;
        private EnrollmentFees enrollmentFees;
        private CouponDetails couponDetails;
        public CourseSelection(string[] inputData)
        {
            try
            {
                cart = new Cart();

                cart.InitializeValues(inputData);

                ProMembership.CheckAndCalculateMembershipDiscount(ref cart);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
        }
        public void CheckAndApplyCoupon()
        {
            couponDetails = new CouponDetails().ApplyCoupon(cart.PurchasedProgrammes)
                                       .CalculateCouponDiscount(cart.PurchasedProgrammes, cart.TotalAmount);

            cart.TotalAmount -= couponDetails.CouponDiscount;
        }
        public void CheckAndApplyEnrollment()
        {
            enrollmentFees = new EnrollmentFees().CheckEnrollmentFeesApplicableOrNot(cart.TotalAmount);

            cart.TotalAmount += enrollmentFees.Fees;
        }
        public void PrintOutput()
        {
            Console.WriteLine("SUB_TOTAL " + String.Format("{0:0.00}", cart.SubTotal));

            Console.WriteLine("COUPON_DISCOUNT " + couponDetails.CouponName.ToString() + " " +
                                String.Format("{0:0.00}", couponDetails.CouponDiscount));

            Console.WriteLine("TOTAL_PRO_DISCOUNT " + String.Format("{0:0.00}", cart.ProMembershipDiscount));

            Console.WriteLine("PRO_MEMBERSHIP_FEE " + String.Format("{0:0.00}", cart.ProMembershipFees));

            Console.WriteLine("ENROLLMENT_FEE " + String.Format("{0:0.00}", enrollmentFees.Fees));

            Console.WriteLine("TOTAL " + String.Format("{0:0.00}", cart.TotalAmount));
        }
    }
}

