﻿namespace GeekTrust
{
    public class ProgrammeDetails 
    {
        private string programmeName;
        private double programmeFees;
        public string ProgrammeName
        {
            get { return programmeName; }
            set { programmeName = value; }
        }
        public double ProgrammeFees
        {
            get { return programmeFees; }
            set { programmeFees = value; }
        }
    }
}
