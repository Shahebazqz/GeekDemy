﻿using System.Collections.Generic;
using System.Linq;

namespace GeekTrust
{
    public class CouponDetails : ICoupon
    {
        private Coupon couponName;
        private double couponDiscount = 0;
        private readonly int minimumProgrammesForB4G1 = 4;
        private readonly int minimumProgrammesForDEAL_G5 = 2;
        private readonly double minimumFeesForDEAL_G20 = 10000;
        private readonly double discountForDEAL_G20 = 0.20;
        private readonly double discountForDEAL_G5 = 0.05;

        public Coupon CouponName
        {
            get { return couponName; }
            set { couponName = value; }
        }
        public double CouponDiscount
        {
            get { return couponDiscount; }
            set { couponDiscount = value; }
        }
        public CouponDetails ApplyCoupon(List<PurchasedProgramme> programmes)
        {
            var CountProgrammes = programmes.Sum(e => e.Quantity);

            var TotalFees = programmes.Sum(e => e.Quantity * e.Fees);

            if (CountProgrammes >= this.minimumProgrammesForB4G1)
                this.couponName = Coupon.B4G1;
            
            else if (TotalFees >= this.minimumFeesForDEAL_G20 && Program.AddedCoupons.Contains(Coupon.DEAL_G20))
                this.couponName = Coupon.DEAL_G20;

            else if (CountProgrammes >= this.minimumProgrammesForDEAL_G5 && Program.AddedCoupons.Contains(Coupon.DEAL_G5))
                this.couponName = Coupon.DEAL_G5;
            
            else
                this.couponName = Coupon.NONE;
            
            return this;
        }

        public CouponDetails CalculateCouponDiscount(List<PurchasedProgramme> purchasedProgrammes, double totalAmount)
        {
            switch (CouponName)
            {
                case Coupon.B4G1:
                    CouponDiscount = purchasedProgrammes.Min(e => e.Fees);
                    break;

                case Coupon.DEAL_G20:
                    CouponDiscount = totalAmount * this.discountForDEAL_G20;
                    break;

                case Coupon.DEAL_G5:
                    CouponDiscount = totalAmount * this.discountForDEAL_G5;
                    break;
            }
            return this;
        }
    }
}
