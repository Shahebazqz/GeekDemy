﻿using NUnit.Framework;
using System;
using System.IO;

namespace GeekTrust.Tests
{
    public class ProgramTests
    {
        GeekTrust.Cart cart = new Cart();
        //Assign Variables
        string[] InputCommands = new string[] {
                "ADD_PROGRAMME CERTIFICATION 1",
                "ADD_PROGRAMME DEGREE 1",
                "ADD_PROGRAMME DIPLOMA 2",
                "APPLY_COUPON DEAL_G20",
                "PRINT_BILL"
            };

        [Test]
        public void TestOutput()
        {
            //arrange
            string[] inputData= new string[] {
                "ADD_PROGRAMME CERTIFICATION 1",
                "ADD_PROGRAMME DEGREE 1",
                "ADD_PROGRAMME DIPLOMA 2",
                "APPLY_COUPON DEAL_G20",
                "PRINT_BILL"
            };
            string ExpectedValue = "SUB_TOTAL 13000.00\r\n"
                                 + "COUPON_DISCOUNT B4G1 2500.00\r\n"
                                 + "TOTAL_PRO_DISCOUNT 0.00\r\n"
                                 + "PRO_MEMBERSHIP_FEE 0.00\r\n"
                                 + "ENROLLMENT_FEE 0.00\r\n"
                                 + "TOTAL 10500.00\r\n";
            StringWriter stringWriter = new StringWriter();
            Console.SetOut(stringWriter);

            //act
            CourseSelection courseSelection = new CourseSelection(inputData);

            courseSelection.CheckAndApplyCoupon();

            courseSelection.PrintOutput();

            //assert
            var output = stringWriter.ToString();

            Assert.AreEqual(ExpectedValue, output);
        }

        [Test]
        public void TestInitialization()
        {
            int ExpectedProgrammeCount = 3;
            cart.InitializeValues(InputCommands);
            Assert.AreEqual(ExpectedProgrammeCount, cart.PurchasedProgrammes.Count);
        }
        [Test]
        public void TestWrongInputProgrammes()
        {
            string[] WrongInputCommands = new string[] {
                "ADD_PROGRAMME CERTIFICATION_ sd1",
                "ADD_PROGRAMME DEGREE_ 1",
                "ADD_PROGRAMME DIPLOMA 2",
                "APPLY_COUPON DEAL_G20",
                "PRINT_BILL"
            };
            Assert.Throws<System.NullReferenceException>(() => cart.InitializeValues(WrongInputCommands));
        }
        [Test]
        public void TestWrongInputCommands()
        {
            string[] WrongInputCommands = new string[] {
                "ADD_PROGRAMME_ CERTIFICATION 1",
                "ADD_PROGRAMME@ DEGREE 1",
                "ADD_PROGRAMME DIPLOMA 2",
                "APPLY_COUPON DEAL_G20",
                "PRINT_BILL"
            };
            Assert.Throws<System.NullReferenceException>(() => cart.InitializeValues(WrongInputCommands));
        }
        [Test]
        public void TestAddProgramme()
        {
            string[] InputCommands = new string[] {
                "ADD_PROGRAMME CERTIFICATION 1",
                "ADD_PROGRAMME DEGREE 1",
                "ADD_PROGRAMME DIPLOMA 2",
                "APPLY_COUPON DEAL_G20",
                "PRINT_BILL"
            };
            string ExpectedProgrammeName = "CERTIFICATION";
            cart.InitializeValues(InputCommands);
            Assert.AreEqual(ExpectedProgrammeName, cart.PurchasedProgrammes[0].Name);
        }
        [Test]
        public void TestSubTotal()
        {
            double ExpectedSubTotal = 13000;
            cart.InitializeValues(InputCommands);
            Assert.AreEqual(ExpectedSubTotal, cart.TotalAmount);
        }
        [Test]
        public void TestCheckAndCalculateMembershipDiscount()
        {
            double ExpectedDiscount = 0;
            cart = new Cart();
            cart.InitializeValues(InputCommands);
            ProMembership.CheckAndCalculateMembershipDiscount(ref cart);
            Assert.AreEqual(ExpectedDiscount, cart.ProMembershipDiscount);
        }
        [Test]
        public void TestCalculateTotalAmount()
        {
            string[] inputCommands = new string[] {
                "ADD_PROGRAMME CERTIFICATION 1",
                "ADD_PROGRAMME DEGREE 1",
                "ADD_PROGRAMME DIPLOMA 2",
                "ADD_PRO_MEMBERSHIP",
                "APPLY_COUPON DEAL_G20",
                "PRINT_BILL"
            };
            double ExpectedTotalAmount = 12940;

            cart = new Cart();
            cart.InitializeValues(inputCommands);
            ProMembership.CheckAndCalculateMembershipDiscount(ref cart);
            Assert.AreEqual(ExpectedTotalAmount, cart.TotalAmount);
        }
        [Test]
        public void TestCheckEnrollmentFeesApplicableOrNot()
        {
            double fees = 5000;
            double expectedValue = 500;
            var enrollmentFees = new EnrollmentFees().CheckEnrollmentFeesApplicableOrNot(fees);
            Assert.AreEqual(expectedValue, enrollmentFees.Fees);
        }
        [Test]
        public void TestApplyCoupon()
        {
            Coupon expectedCoupon = Coupon.B4G1;
            string[] inputCommands = new string[] {
                "ADD_PROGRAMME CERTIFICATION 1",
                "ADD_PROGRAMME DEGREE 1",
                "ADD_PROGRAMME DIPLOMA 2",
                "ADD_PRO_MEMBERSHIP",
                "APPLY_COUPON DEAL_G20",
                "PRINT_BILL"
            };
            cart = new Cart();
            cart.InitializeValues(inputCommands);
            CouponDetails couponDetails = new CouponDetails().ApplyCoupon(cart.PurchasedProgrammes);
            Assert.AreEqual(expectedCoupon, couponDetails.CouponName);
        }
        [Test]
        public void TestCalculateCouponDiscount()
        {
            
            double expectedValue = 2500;
            string[] inputCommands = new string[] {
                "ADD_PROGRAMME CERTIFICATION 1",
                "ADD_PROGRAMME DEGREE 1",
                "ADD_PROGRAMME DIPLOMA 2",
                "ADD_PRO_MEMBERSHIP",
                "APPLY_COUPON DEAL_G20",
                "PRINT_BILL"
            };
            cart = new Cart();
            cart.InitializeValues(inputCommands);
            CouponDetails couponDetails = new CouponDetails().ApplyCoupon(cart.PurchasedProgrammes)
                                            .CalculateCouponDiscount(cart.PurchasedProgrammes, cart.TotalAmount);
            Assert.AreEqual(expectedValue, couponDetails.CouponDiscount);
        }
    }
}
